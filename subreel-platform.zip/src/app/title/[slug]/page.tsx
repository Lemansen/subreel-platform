import Link from "next/link";
import { connection } from "next/server";
import { Suspense } from "react";
import { notFound, unstable_rethrow } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import {
  contentLabels,
  coverBackground,
  firstOf,
  incomingRelationLabels,
  outgoingRelationLabels,
} from "@/lib/catalog";

type Params = Promise<{ slug: string }>;

type TitleRow = {
  id: string;
  franchise_id: string | null;
  name: string;
  original_name: string | null;
  slug: string;
  description: string | null;
  cover_url: string | null;
  banner_url: string | null;
  content_type: string;
  release_year: number | null;
};

type TitleBrief = {
  name: string;
  slug: string;
  content_type: string;
  release_year: number | null;
  cover_url: string | null;
};

type RelationItem = { label: string; title: TitleBrief };

const SLUG_RE = /^[a-z0-9]+(-[a-z0-9]+)*$/;
const BRIEF = "name, slug, content_type, release_year, cover_url";

async function loadTitle(slug: string) {
  const supabase = await createClient();

  const { data: title, error } = await supabase
    .from("titles")
    .select(
      "id, franchise_id, name, original_name, slug, description, cover_url, banner_url, content_type, release_year"
    )
    .eq("slug", slug)
    .eq("status", "published")
    .maybeSingle();

  if (error) throw new Error(`titles query failed: ${error.message}`);
  if (!title) return null;

  const row = title as TitleRow;

  const [genresRes, outRes, inRes, franchiseRes, siblingsRes] =
    await Promise.all([
      supabase
        .from("title_genres")
        .select("genres(name, slug)")
        .eq("title_id", row.id),
      supabase
        .from("title_relationships")
        .select(
          `relationship_type, target:titles!title_relationships_target_title_id_fkey(${BRIEF})`
        )
        .eq("source_title_id", row.id),
      supabase
        .from("title_relationships")
        .select(
          `relationship_type, source:titles!title_relationships_source_title_id_fkey(${BRIEF})`
        )
        .eq("target_title_id", row.id),
      row.franchise_id
        ? supabase
            .from("franchises")
            .select("name, slug")
            .eq("id", row.franchise_id)
            .eq("status", "published")
            .maybeSingle()
        : Promise.resolve({ data: null, error: null }),
      row.franchise_id
        ? supabase
            .from("titles")
            .select(BRIEF)
            .eq("franchise_id", row.franchise_id)
            .eq("status", "published")
            .neq("id", row.id)
            .order("release_year", { ascending: true, nullsFirst: false })
            .limit(12)
        : Promise.resolve({ data: [], error: null }),
    ]);

  // Второстепенные блоки не должны ронять страницу целиком.
  for (const [name, res] of [
    ["genres", genresRes],
    ["relations_out", outRes],
    ["relations_in", inRes],
    ["franchise", franchiseRes],
    ["siblings", siblingsRes],
  ] as const) {
    if (res.error) console.error(`[title/${slug}] ${name} failed:`, res.error.message);
  }

  const genres = ((genresRes.data ?? []) as { genres: unknown }[])
    .map((g) => firstOf(g.genres as { name: string; slug: string } | null))
    .filter((g): g is { name: string; slug: string } => g !== null);

  const relations: RelationItem[] = [];
  for (const r of (outRes.data ?? []) as {
    relationship_type: string;
    target: TitleBrief | TitleBrief[] | null;
  }[]) {
    const t = firstOf(r.target);
    if (t) {
      relations.push({
        label: outgoingRelationLabels[r.relationship_type] ?? r.relationship_type,
        title: t,
      });
    }
  }
  for (const r of (inRes.data ?? []) as {
    relationship_type: string;
    source: TitleBrief | TitleBrief[] | null;
  }[]) {
    const t = firstOf(r.source);
    if (t) {
      relations.push({
        label: incomingRelationLabels[r.relationship_type] ?? r.relationship_type,
        title: t,
      });
    }
  }

  return {
    title: row,
    genres,
    relations,
    franchise: (franchiseRes.data ?? null) as { name: string; slug: string } | null,
    siblings: (siblingsRes.data ?? []) as TitleBrief[],
  };
}

function MiniCard({ title, caption }: { title: TitleBrief; caption?: string }) {
  return (
    <Link
      href={`/title/${title.slug}`}
      className="group flex gap-4 rounded-2xl border border-white/[0.08] bg-white/[0.025] p-3 transition hover:border-violet-400/40 hover:bg-white/[0.05] focus-visible:outline focus-visible:outline-2 focus-visible:outline-violet-400"
    >
      <div className="relative h-24 w-[72px] shrink-0 overflow-hidden rounded-lg bg-gradient-to-br from-violet-950 via-[#171321] to-[#0e0e14]">
        {title.cover_url && (
          <div
            role="img"
            aria-label={`Обложка: ${title.name}`}
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: coverBackground(title.cover_url) }}
          />
        )}
      </div>
      <div className="min-w-0 py-1">
        {caption && <p className="text-xs text-violet-300">{caption}</p>}
        <p className="mt-1 line-clamp-2 font-semibold transition group-hover:text-violet-300">
          {title.name}
        </p>
        <p className="mt-1 text-xs text-zinc-400">
          {contentLabels[title.content_type] ?? title.content_type}
          {title.release_year ? `, ${title.release_year}` : ""}
        </p>
      </div>
    </Link>
  );
}

async function TitleContent({ params }: { params: Params }) {
  await connection();
  const { slug } = await params;

  if (!SLUG_RE.test(slug)) notFound();

  let data: Awaited<ReturnType<typeof loadTitle>>;
  try {
    data = await loadTitle(slug);
  } catch (error) {
    unstable_rethrow(error);
    console.error(`[title/${slug}] load failed:`, error);
    return (
      <main className="min-h-screen bg-[#09090d] px-5 py-16 text-white sm:px-8">
        <div className="mx-auto max-w-2xl rounded-2xl border border-amber-400/20 bg-amber-400/[0.05] p-8">
          <h1 className="font-semibold text-amber-200">
            Не удалось загрузить страницу
          </h1>
          <p className="mt-2 text-sm leading-6 text-zinc-400">
            Попробуй обновить страницу чуть позже.
          </p>
          <Link href="/" className="mt-5 inline-block text-sm text-violet-300 hover:text-violet-200">
            ← На главную
          </Link>
        </div>
      </main>
    );
  }

  if (!data) notFound();

  const { title, genres, relations, franchise, siblings } = data;
  const heroImage = title.banner_url ?? title.cover_url;

  return (
    <main className="min-h-screen bg-[#09090d] text-white">
      <header className="border-b border-white/[0.08] bg-[#09090d]/90">
        <div className="mx-auto flex h-[72px] max-w-7xl items-center justify-between px-5 sm:px-8">
          <Link href="/" className="text-2xl font-black tracking-tight">
            Sub<span className="text-violet-400">Reel</span>
          </Link>
          <Link
            href="/#catalog"
            className="text-sm text-zinc-400 transition hover:text-white"
          >
            ← Каталог
          </Link>
        </div>
      </header>

      <section className="relative isolate overflow-hidden border-b border-white/[0.06]">
        {heroImage && (
          <div
            aria-hidden="true"
            className="absolute inset-0 -z-10 scale-110 bg-cover bg-center opacity-25 blur-2xl"
            style={{ backgroundImage: coverBackground(heroImage) }}
          />
        )}
        <div className="mx-auto grid max-w-7xl gap-8 px-5 py-12 sm:px-8 md:grid-cols-[240px_1fr] md:py-16">
          <div className="relative mx-auto aspect-[3/4] w-48 overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-violet-950 via-[#171321] to-[#0e0e14] md:w-full">
            {title.cover_url ? (
              <div
                role="img"
                aria-label={`Обложка: ${title.name}`}
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: coverBackground(title.cover_url) }}
              />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center text-2xl font-black text-white/25">
                SubReel
              </div>
            )}
          </div>

          <div>
            <p className="text-sm text-zinc-300">
              {contentLabels[title.content_type] ?? title.content_type}
              {title.release_year ? `, ${title.release_year}` : ""}
              {franchise ? ` · Франшиза «${franchise.name}»` : ""}
            </p>
            <h1 className="mt-3 text-4xl font-black leading-tight tracking-tight sm:text-5xl">
              {title.name}
            </h1>
            {title.original_name && title.original_name !== title.name && (
              <p className="mt-2 text-base text-zinc-400">{title.original_name}</p>
            )}

            {genres.length > 0 && (
              <ul className="mt-5 flex flex-wrap gap-2">
                {genres.map((g) => (
                  <li
                    key={g.slug}
                    className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs text-zinc-300"
                  >
                    {g.name}
                  </li>
                ))}
              </ul>
            )}

            {title.description ? (
              <p className="mt-6 max-w-2xl whitespace-pre-line text-sm leading-7 text-zinc-300">
                {title.description}
              </p>
            ) : (
              <p className="mt-6 text-sm text-zinc-500">Описание пока не добавлено.</p>
            )}

            <p className="mt-8 rounded-xl border border-dashed border-white/15 px-4 py-3 text-sm text-zinc-400">
              Смотреть и читать здесь пока нельзя: плеер и читалка ещё в разработке.
            </p>
          </div>
        </div>
      </section>

      {relations.length > 0 && (
        <section className="mx-auto max-w-7xl px-5 py-12 sm:px-8">
          <h2 className="text-2xl font-bold tracking-tight">Связанные произведения</h2>
          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {relations.map((r) => (
              <MiniCard key={`${r.label}-${r.title.slug}`} title={r.title} caption={r.label} />
            ))}
          </div>
        </section>
      )}

      {siblings.length > 0 && (
        <section className="mx-auto max-w-7xl px-5 pb-16 sm:px-8">
          <h2 className="text-2xl font-bold tracking-tight">
            Ещё во франшизе{franchise ? ` «${franchise.name}»` : ""}
          </h2>
          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {siblings.map((s) => (
              <MiniCard key={s.slug} title={s} />
            ))}
          </div>
        </section>
      )}
    </main>
  );
}

export default function TitlePage({ params }: { params: Params }) {
  return (
    <Suspense
      fallback={
        <main className="min-h-screen bg-[#09090d] p-8 text-white">
          <p className="animate-pulse text-sm text-zinc-400">Загружаем тайтл...</p>
        </main>
      }
    >
      <TitleContent params={params} />
    </Suspense>
  );
}
